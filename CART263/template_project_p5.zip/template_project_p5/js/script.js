"use strict";

function preload() {}

function setup() {}

function draw() {}
