$(document).ready(go);

function go(){
  console.log("we are ready to go");
}
